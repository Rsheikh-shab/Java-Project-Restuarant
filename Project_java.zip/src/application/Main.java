package application;
	
import java.io.File;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;


public class Main extends Application {
	

	 
	Stage window;
	Scene scene1,scene2,scene3,scene4;
	String totalPrice="";
	double total=0;
	 
	 ComboBox<String> ComboBOx,ComboBOx1;
	
	
	public Scene getScene(){
		
		Button b2=new Button("Close");
		b2.setStyle("-fx-font-size:20;");
		b2.setOnAction(e->window.close());
		
		Button b3=new Button("Home");
		b3.setStyle("-fx-font-size:20;");
		b3.setOnAction(e->window.setScene(scene1));
		
		Label la2=new Label("  Friends & Family");
		la2.setStyle("-fx-font-size:40;");
		
		Label la3=new Label("        Resturant");
		la3.setStyle("-fx-font-size:35;");
		Label la4=new Label("            Receipt");
		la4.setStyle("-fx-font-size:30;");
		
		Label resultL = new  Label(totalPrice);
		Label dag1 = new  Label("      _______________________________");
		dag1.setStyle("-fx-font-size:20;");
		Label dag = new  Label("________________________________");
		Label totalL = new  Label("Total Cost -------- "+total);
		resultL.setMinHeight(100);
		
		GridPane hbox3=new GridPane();
		hbox3.setVgap(5);
		hbox3.setHgap(5);
		hbox3.add(b2, 6,28 );
		hbox3.add(b3, 2, 28);
		hbox3.add(la2, 3, 2);
		hbox3.add(la3, 3, 3);
		hbox3.add(dag1, 3, 4);
		hbox3.add(la4, 3, 5);
		hbox3.add(resultL, 3, 8);
		hbox3.add(dag, 3, 9);
		hbox3.add(totalL, 3, 10);
		hbox3.setStyle("-fx-background: #E0FFFF");
		
		
		scene4=new Scene(hbox3);
		
		//GridPane.setHalignment(resultL, HPos.LEFT);
		GridPane.setHalignment(b2, HPos.RIGHT);
		GridPane.setHalignment(b3, HPos.RIGHT);
		GridPane.setHalignment(resultL, HPos.CENTER);
		GridPane.setHalignment(dag, HPos.CENTER);
		GridPane.setHalignment(totalL, HPos.CENTER);
		
		
		
		StackPane Scene4=new StackPane();
		Scene4.getChildren().addAll(hbox3);
		return new Scene(Scene4,600,600);
		
	}
	
	
	
	public void start(Stage primaryStage) {
		window=primaryStage;
		
		
		//PraimaryScene;
	
		
		Button button=new Button("Foods");
		button.setStyle("-fx-font-size:30;");
		button.setOnAction(e->window.setScene(scene2));
		
		
		Button button1=new Button("Drinks");
		button1.setStyle("-fx-font-size:30;");
		button1.setOnAction(e->window.setScene(scene3));
		
		
		
		
		Image image=new Image(new File("/Users/tariftuhin/Documents/workspace/FinalPro/src/imageview/main.jpg").toURI().toString());
		ImageView img=new ImageView(image);
		
		Label l=new Label("        Friends & Family Resturant");
		l.setStyle("-fx-font-size:50;");
		
		Label moto=new Label("                               'We provide all kind of food whatever you want '\n"+"\t\t\t\t\t\tProviding 100% HALAL Food");
		moto.setStyle("-fx-font-size:20;");
		
		Label l1=new Label("-------------------------------------------------------------------------------------");
		l1.setStyle("-fx-font-size:20; ");
		
		
		
		

		GridPane hbox=new GridPane();
		hbox.setVgap(5);
		hbox.setHgap(5);
		hbox.add(l, 15, 1);
		hbox.add(l1, 15, 2);
		hbox.add(moto, 15, 3);
		hbox.add(button, 15,20 );
		hbox.add(button1, 15,20 );
		
		hbox.add(img, 15, 12);
		hbox.setStyle("-fx-background: #3CB371");
		
		
		
		
		GridPane.setHalignment(button, HPos.LEFT);
		GridPane.setHalignment(button1, HPos.RIGHT);
	   

		scene1=new Scene(hbox,1000,700);
		
		
		//scene2
		
		
		
		TextField t1=new TextField();
		t1.setPromptText("How many");
		
		
		ComboBOx=new ComboBox<String>();
		ComboBOx.getItems().addAll("Rice",
				"Polao",
				"Nasi lamak",
				"Chicken",
				"Dry Fish",
				"Beaf",
				"Mutton",
				"Fish"
				);
		//ComboBOx.setOnAction(e->System.out.println(ComboBOx.getValue()));
		
        ComboBOx.setOnAction(e -> {
            //System.out.println(ComboBOx.getValue());
            switch (ComboBOx.getValue()) {
                case "Rice":
                	total+=1.50*Integer.parseInt(t1.getText());
                    totalPrice+=("Rice -------- "+(1.50*Integer.parseInt(t1.getText()))+"\n");
                    break;
                case "Polao":
                	total+=3.50*Integer.parseInt(t1.getText());
                    totalPrice+=("Polao -----------"+3.50*Integer.parseInt(t1.getText())+"\n");
                    break;
                case "Chicken":
                	total+=2.50*Integer.parseInt(t1.getText());
                    totalPrice+=("Chicken ---------"+2.50*Integer.parseInt(t1.getText())+"\n");
                    break;
                case "Dry Fish":
                	total+=2.00*Integer.parseInt(t1.getText());
                    totalPrice+=("Dry Fish --------"+2.00*Integer.parseInt(t1.getText())+"\n");
                    break;
                case "Beaf":
                	total+=4.00*Integer.parseInt(t1.getText());
                	totalPrice+=("Beaf ------------"+4.00*Integer.parseInt(t1.getText())+"\n");
                    break;
                case "Nasi lamak":
                	total+=1.50*Integer.parseInt(t1.getText());
                	totalPrice+=("Nasi lamak ------"+1.50*Integer.parseInt(t1.getText())+"\n");
                    break;
                case "Fish":
                	total+=3.00*Integer.parseInt(t1.getText());
                	totalPrice+=("Fish-------------"+3.00*Integer.parseInt(t1.getText())+"\n");
                    break;
                case "Mutton":
                	total+=5.00*Integer.parseInt(t1.getText());
                	totalPrice+=("Mutton ----------"+5.00*Integer.parseInt(t1.getText())+"\n");
                    break;
                default:
                    break;
            }
        });
        
        

		
		ComboBOx.setStyle("-fx-font-size:15;");
		ComboBOx.setPromptText("Select items");
		
		/*
		ComboBOx1=new ComboBox<>();
		ComboBOx1.getItems().addAll("Rice---1.50",
				"Polao---3.50",
				"Khichuri---2.50"
				);
		ComboBOx1.setPromptText("Select items");*/
		
		Button Button1=new Button("Home");
		Button1.setStyle("-fx-font-size:20;");
		Button1.setOnAction(e->window.setScene(scene1));
		
		Button button2=new Button("Drinks");
		button2.setStyle("-fx-font-size:20;");
		button2.setOnAction(e->window.setScene(scene3));
		
		Button Button2=new Button("Print");
		Button2.setStyle("-fx-font-size:20;");
		Button2.setOnAction(e->{
			window.setScene(getScene());
			//System.out.println(totalPrice);
		});
		
		
		
		
		Image image1=new Image(new File("/Users/tariftuhin/Documents/workspace/FinalPro/src/imageview/scene2 copy.jpg").toURI().toString());
		ImageView img1=new ImageView(image1);
		
		
		/*
		TextArea cssEditorFld = new TextArea();
        cssEditorFld.setPrefRowCount(10);
        cssEditorFld.setPrefColumnCount(100);
        //cssEditorFld.setWrapText(true);
        cssEditorFld.setPrefWidth(300);
        cssEditorFld.setPrefHeight(200);
        
        GridPane.setHalignment(cssEditorFld, HPos.RIGHT);
        String cssDefault = "line1;\nline2;\n";
        cssEditorFld.setText(cssDefault);
		*/
		
		Label l2=new Label("MENU                 \t\t\tPRICE         \t\tMENU\t                  \t\t\t\t PRICE\n-----------------------------------                     \t---------------------------------------------");
		l2.setStyle("-fx-font-size:15;");
		Label l3=new Label("Rice-------------------------\tRM1.50\t\t\t\tDry Fish\t---------------------------\t RM2.00\n"
				+ "Polao------------------------\tRM3.50\t\t\t\tBeaf\t---------------------------\t\t RM4.00\n"
				+ "Nasi lamak-------------------\tRM1.50\t\t\t\tMutton\t-------------------------\t RM5.00\n"
				+ "Chicken----------------------\tRM2.50\t\t\t\tFish\t---------------------------\t\t RM3.00\n");
		
		Label la=new Label("      Friends & Family Resturant");
		la.setStyle("-fx-font-size:40;");
		
		VBox vbox=new VBox();
		vbox.getChildren().addAll(t1,ComboBOx);
		vbox.setMaxWidth(200);
		vbox.setMaxHeight(10);
		vbox.setSpacing(50);
		
		HBox box=new HBox();
		box.getChildren().addAll(Button1,button2,Button2);
		box.setSpacing(8);
		

		GridPane hbox1=new GridPane();
		hbox1.setVgap(3);
		hbox1.setHgap(3);
		hbox1.add(vbox, 28, 15);
		hbox1.add(box, 28, 35);
		//hbox1.add(cssEditorFld, 20, 17);
		hbox1.add(l2,22 ,17 );
		hbox1.add(l3,22 ,18 );
		hbox1.add(la, 22, 35);
		hbox1.add(img1, 22, 15);
		hbox1.setStyle("-fx-background:#FDF5E6");
		scene2=new Scene(hbox1);
		
		GridPane.setHalignment(ComboBOx, HPos.RIGHT);
		GridPane.setHalignment(t1, HPos.RIGHT);
		GridPane.setHalignment(box, HPos.LEFT);
		GridPane.setHalignment(img1, HPos.RIGHT);
		GridPane.setHalignment(vbox, HPos.RIGHT);
		GridPane.setHalignment(la, HPos.LEFT);
		
		
		
		
		
		StackPane Scene2=new StackPane();
		Scene2.getChildren().addAll(hbox1);
		scene2=new Scene(Scene2,1050,700);
		
		//scene3
		
		
		Button Cbutton1=new Button("Home");
		Cbutton1.setStyle("-fx-font-size:20;");
		Cbutton1.setOnAction(e->window.setScene(scene1));
		
		Button Cbutton2=new Button("Foods");
		Cbutton2.setStyle("-fx-font-size:20;");
		Cbutton2.setOnAction(e->window.setScene(scene2));
		
		
		Button Cbutton3=new Button("Print");
		Cbutton3.setStyle("-fx-font-size:20;");
		
		Cbutton3.setOnAction(e->{
			window.setScene(getScene());
			//System.out.println(totalPrice);
		});
		
		
		Image image2=new Image(new File("/Users/tariftuhin/Documents/workspace/FinalPro/src/imageview/scene3.1.jpg").toURI().toString());
		ImageView img2=new ImageView(image2);
		
		TextField t2=new TextField();
		t2.setPromptText("How many");
		
		
		ComboBOx1=new ComboBox<>();
		ComboBOx1.getItems().addAll("Mango",
				"Water melon",
				"Banana",
				"Mixed",
				"Ieclemon tea",
				"Milo",
				"Orange",
				"Apple"
				);
		
		 ComboBOx1.setOnAction(e -> {
	            //System.out.println(ComboBOx.getValue());
	            switch (ComboBOx1.getValue()) {
	                case "Water melon":
	                	total+=3.00*Integer.parseInt(t2.getText());
	                	totalPrice+=("Water melon ----- "+(3.00*Integer.parseInt(t2.getText()))+"\n");
	                    break;
	                case "Banana":
	                	total+=2.00*Integer.parseInt(t2.getText());
	                	totalPrice+=("Banana------------"+2.00*Integer.parseInt(t2.getText())+"\n");
	                    break;
	                case "Mixed":
	                	total+=3.00*Integer.parseInt(t2.getText());
	                	totalPrice+=("Mixed ------------"+3.00*Integer.parseInt(t2.getText())+"\n");
	                    break;
	                case "Ieclemon tea":
	                	total+=1.50*Integer.parseInt(t2.getText());
	                	totalPrice+=("Ieclemon tea------"+1.50*Integer.parseInt(t2.getText())+"\n");
	                    break;
	                case "Mango":
	                	total+=3.00*Integer.parseInt(t2.getText());
	                	totalPrice+=("Mango ------------"+3.00*Integer.parseInt(t2.getText())+"\n");
	                    break;
	                case "Milo":
	                	total+=1.00*Integer.parseInt(t2.getText());
	                	totalPrice+=("Milo -------------"+1.00*Integer.parseInt(t2.getText())+"\n");
	                    break;
	                case "Orange":
	                	total+=3.00*Integer.parseInt(t2.getText());
	                	totalPrice+=("Orange -----------"+3.00*Integer.parseInt(t2.getText())+"\n");
	                    break;
	                case "Apple":
	                	total+=3.00*Integer.parseInt(t2.getText());
	                	totalPrice+=("Apple ------------"+3.00*Integer.parseInt(t2.getText())+"\n");
	                    break;
	                default:
	                    break;
	            }
	        });
		
		
		ComboBOx1.setStyle("-fx-font-size:15;");
		ComboBOx1.setPromptText("Select items");
		
		
		
		
		Label l4=new Label("MENU            \t\t\tPRICE            \t\t\tMENU                    \t\t\t PRICE\n------------------------------                \t    ---------------------------------------");
		l4.setStyle("-fx-font-size:15;");
		Label l5=new Label("Mango-----------------\tRM3.00\t  \t\t\t\tIeclemon tea\t-----------\t\t RM1.50\n"
				+ "Water melon----------\tRM3.00\t\t\t\t\tMilo\t-----------------\t\t\t RM1.00\n"
				+ "Banana---------------\tRM2.00\t\t\t\t\tOrange\t-----------------\t\t RM1.00\n"
				+ "Mixed-----------------\tRM3.00\t\t\t\t\tApple\t-----------------\t\t RM1.00\n");
		
		
		Label la1=new Label("     Friends & Family Resturant");
		la1.setStyle("-fx-font-size:40;");
		//la1.setStyle("-fx-font-style:italic;");
		//la1.setStyle("-fx-font-color:blue;");
		
		
		VBox vbox1=new VBox();
		vbox1.getChildren().addAll(t2,ComboBOx1);
		vbox1.setMaxWidth(200);
		vbox1.setMaxHeight(10);
		vbox1.setSpacing(50);
		
		
		
		HBox box1=new HBox();
		box1.getChildren().addAll(Cbutton1,Cbutton2,Cbutton3);
		box1.setSpacing(8);
		
		GridPane hbox2=new GridPane();
		hbox2.setVgap(3);
		hbox2.setHgap(3);
		hbox2.add(box1, 28, 35);
		hbox2.add(img2, 20, 15);
		hbox2.add(vbox1, 28, 15);
		hbox2.add(l4,20 ,17 );
		hbox2.add(l5,20 ,18 );
		hbox2.add(la1, 20, 35);
		
		
		GridPane.setHalignment(box1, HPos.LEFT);
		GridPane.setHalignment(img2, HPos.LEFT);
		GridPane.setHalignment(vbox1, HPos.RIGHT);
		
		scene3=new Scene(hbox2);
		hbox2.setStyle("-fx-background: #E0FFFF");
		
		StackPane Scene3=new StackPane();
		Scene3.getChildren().addAll(hbox2);
		scene3=new Scene(Scene3,1050,700);
		
	
		//scene4
	
		
		
		
		
		
		window.setScene(scene1);
		window.show();
		
		
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
}


